import {SET_PLAY} from "../constants"

export const setPlay = play => ({
    type: SET_PLAY,
    play
  });
  